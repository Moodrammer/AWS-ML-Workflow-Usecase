from ppft import *
from ppft import __version__, __author__, __doc__, __license__

#FIXME: more imports from ppft.__init__
